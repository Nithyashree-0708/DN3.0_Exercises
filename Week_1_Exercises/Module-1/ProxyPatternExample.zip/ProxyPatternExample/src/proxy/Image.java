package proxy;

public interface Image {
    void display();

}
