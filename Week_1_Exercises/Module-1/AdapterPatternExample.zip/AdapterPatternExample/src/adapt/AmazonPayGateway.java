package adapt;

public class AmazonPayGateway {
public void pay(double amount) {
        System.out.println("Payment of $" + amount + " processed from Amazon Pay.");
    }


}
