package invent;

import java.util.HashMap;


public class InventoryManagementSystem {
	private HashMap<String, Product> inventory;

    public InventoryManagementSystem() {
        inventory = new HashMap<>();
    }
    public void addProduct(Product product) {
        inventory.put(product.getProductId(), product);
    }
    public void updateProduct(String productId, Product updatedProduct) {
        if (inventory.containsKey(productId)) {
            inventory.put(productId, updatedProduct);
        } else {
            System.out.println("Product not found.");
        }
    }
    public void deleteProduct(String productId) {
        if (inventory.containsKey(productId)) {
            inventory.remove(productId);
        } else {
            System.out.println("Product not found.");
        }
    }
    public Product getProduct(String productId) {
        return inventory.get(productId);
    }
    public static void main(String[] args) {
        InventoryManagementSystem inventorySystem = new InventoryManagementSystem();
        Product p1 = new Product("001", "Laptop", 10, 999.99);
        Product p2 = new Product("002", "Smartphone", 20, 499.99);
        inventorySystem.addProduct(p1);
        inventorySystem.addProduct(p2);
        System.out.println("Product 001: " + inventorySystem.getProduct("001"));
        System.out.println("Product 002: " + inventorySystem.getProduct("002"));
        Product updatedProduct = new Product("001", "Gaming Laptop", 5, 1499.99);
        inventorySystem.updateProduct("001", updatedProduct);
        System.out.println("Updated Product 001: " + inventorySystem.getProduct("001"));
        inventorySystem.deleteProduct("002");
        if (inventorySystem.getProduct("002") == null) {
            System.out.println("Product 002 has been deleted.");
        }
    }


}
