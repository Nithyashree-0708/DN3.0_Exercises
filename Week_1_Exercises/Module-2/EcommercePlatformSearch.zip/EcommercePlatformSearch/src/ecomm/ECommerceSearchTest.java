package ecomm;

public class ECommerceSearchTest {
	public static void main(String[] args) {
        Product[] products = {
            new Product("003", "Headphones", "Electronics"),
            new Product("001", "Laptop", "Electronics"),
            new Product("002", "Smartphone", "Electronics"),
            new Product("004", "Mouse", "Accessories")
        };
        System.out.println("Testing Linear Search:");
        Product linearSearchResult = SearchUtil.linearSearch(products, "002");
        if (linearSearchResult != null) {
            System.out.println("Found with Linear Search: " + linearSearchResult);
        } else {
            System.out.println("Product not found with Linear Search.");
        }

        System.out.println("\nTesting Binary Search:");
        Product binarySearchResult = SearchUtil.binarySearch(products, "002");
        if (binarySearchResult != null) {
            System.out.println("Found with Binary Search: " + binarySearchResult);
        } else {
            System.out.println("Product not found with Binary Search.");
        }

        System.out.println("\nTesting Binary Search for non-existing product:");
        Product binarySearchNotFound = SearchUtil.binarySearch(products, "999");
        if (binarySearchNotFound != null) {
            System.out.println("Found with Binary Search: " + binarySearchNotFound);
        } else {
            System.out.println("Product not found with Binary Search.");
        }
    }


}
