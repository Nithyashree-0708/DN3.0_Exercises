package w3;

public interface JpaRepository {

}
