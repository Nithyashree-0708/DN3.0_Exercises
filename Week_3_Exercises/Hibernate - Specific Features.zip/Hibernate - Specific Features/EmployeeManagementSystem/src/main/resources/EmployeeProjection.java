package w3;

public interface EmployeeProjection {

}
