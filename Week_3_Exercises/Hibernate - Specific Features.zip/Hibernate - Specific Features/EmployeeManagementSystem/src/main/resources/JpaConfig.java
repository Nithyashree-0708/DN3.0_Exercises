package w3;

public class JpaConfig {

}
