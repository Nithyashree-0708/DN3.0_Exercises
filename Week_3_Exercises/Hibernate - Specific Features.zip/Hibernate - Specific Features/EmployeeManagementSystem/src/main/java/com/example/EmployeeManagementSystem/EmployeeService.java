package EmployeeManagementSystem.src.main.java.com.example.EmployeeManagementSystem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Service
public class EmployeeService {
	@PersistenceContext
    private EntityManager entityManager;

    @Transactional
    public void saveEmployeesBatch(List<Employee> employees) {
        int batchSize = 50;  // Batch size should match the one configured

        for (int i = 0; i < employees.size(); i++) {
            entityManager.persist(employees.get(i));
            if (i % batchSize == 0 && i > 0) {
                entityManager.flush();
                entityManager.clear();
            }
        }
    }

}
