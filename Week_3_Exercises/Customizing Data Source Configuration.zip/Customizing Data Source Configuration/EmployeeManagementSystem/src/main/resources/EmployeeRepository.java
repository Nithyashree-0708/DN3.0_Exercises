package w3;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface EmployeeRepository extends JpaRepository <Employee, Long> {
    Page<Employee> findAll(Pageable pageable);
    List<Employee> findAll(Sort sort);

List<Employee> findByName(String name);
 // Custom query method to find employees by position
    List<Employee> findByPosition(String position);
    
    // Custom query method to find employees by department name
    List<Employee> findByDepartment_DepartmentName(String departmentName);


}
