package EmployeeManagementSystem.src.main.resources;

import w3.JpaRepository;

public interface DepartmentRepository extends JpaRepository <Department, Long> {
	Department findByDepartmentName(String departmentName);
}
