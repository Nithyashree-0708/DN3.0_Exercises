package EmployeeManagementSystem.src.test.java.com.example.EmployeeManagementSystem;

public class AuditingConfig {

}
