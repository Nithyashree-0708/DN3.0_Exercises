package w3;

public class EmployeeDTO extends Employee {

}
