package EmployeeManagementSystem.src.main.java.com.example.EmployeeManagementSystem;

public class PrimaryDataSourceConfig {

}
