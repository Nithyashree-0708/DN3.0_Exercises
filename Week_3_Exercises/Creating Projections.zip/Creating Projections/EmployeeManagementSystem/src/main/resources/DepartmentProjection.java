package EmployeeManagementSystem.src.main.resources;

public interface DepartmentProjection {

}
