package w3;

public abstract class Auditable {

}
