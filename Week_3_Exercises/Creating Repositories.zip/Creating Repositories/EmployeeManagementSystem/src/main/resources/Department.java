package EmployeeManagementSystem.src.main.resources;

public class Department {

}
