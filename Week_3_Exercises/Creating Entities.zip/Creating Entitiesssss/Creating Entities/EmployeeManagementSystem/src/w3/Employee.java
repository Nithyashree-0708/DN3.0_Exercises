package w3;

public class Employee {

}
